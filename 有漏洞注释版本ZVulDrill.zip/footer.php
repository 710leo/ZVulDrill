<hr>
		<div id="footer" class="pull-right">Copyright &copy; 2014 <a href="http://sun710.duapp.com/" target="_blank">Zer0cloud</a></div> 
    </div>
    <script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/bootswatch.js"></script>
  </body>
</html>