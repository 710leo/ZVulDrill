<?php 
require_once('sys/config.php');
require_once('header.php');
?>

		<div class="row">
              <div class="jumbotron" style="text-align: center;">
                <h1><b>ZVulDrill</b></h1>
                <p>一个简单的Web漏洞演练平台</p><br />
              </div>
			  <div class="col-lg-12">
				<h2>一个简单的留言板，包含SQL注入，XSS，CSRF等常见的Web漏洞 </h2>
				<p></p>
			  </div>
        </div>
		
<?php
require_once('footer.php');
?>